<?php
require_once '../vendor/autoload.php';
include '../koneksi.php';
include '../date_formatter.php';
setlocale(LC_TIME, 'id_ID'); // Set lokal ke bahasa Indonesia


// Mengambil data berdasarkan ID peminjaman_ruangan
$id_peminjaman_ruangan = $_GET['id'];
$sql = "SELECT * FROM peminjaman_ruangan LEFT JOIN ruangan ON peminjaman_ruangan.ruangan_id = ruangan.id_ruangan LEFT JOIN mahasiswa ON peminjaman_ruangan.mahasiswa_id = mahasiswa.id_mahasiswa LEFT JOIN gedung ON ruangan.gedung_id = gedung.id_gedung LEFT JOIN biro ON peminjaman_ruangan.biro_id = biro.id_biro LEFT JOIN dosen ON dosen.id_dosen = peminjaman_ruangan.dosen_id LEFT JOIN user ON peminjaman_ruangan.user_id = user.id_user WHERE id_peminjaman_ruangan='$id_peminjaman_ruangan'";
$result = $conn->query($sql);
$data = $result->fetch_assoc();
            
// Creating the new document...
$phpWord = new \PhpOffice\PhpWord\PhpWord();
$indent = array(
    'indentation' => array('left' => 540, 'right' => 120)
);
$indent2 = array(
    'indentation' => array('left' => 1140, 'right' => 120)
);

/* Note: any element you append to a document must reside inside of a Section. */

// Adding an empty Section to the document.
$section = $phpWord->addSection();
$section->addText('Nomor' . str_repeat(' ', 2) . ': ');
$section->addText('Lamp' . str_repeat(' ', 4) . ': ');
$section->addText('Hal' . str_repeat(' ', 8 ) . ': ');

$section->addTextBreak();

$section->addText('Kepada Yang Terhormat,', null, $indent);
$section->addText($data['nama_biro'] == '' ? '-' : $data['nama_biro'], array('bold' => true, 'underline' => 'single'), $indent);
$section->addText('Di - ', null, $indent);
$section->addText('Universitas Darussalam Gontor', null, $indent);
$section->addTextBreak();

$section->addText('Bismillahirrahmanirrahim', array('italic' => true), $indent);
$section->addText('Assalamu’alaikum Wr. Wb', array('italic' => true), $indent);

$section->addTextBreak();
$section->addText('Dengan hormat,', null, $indent);
$section->addText('Dengan ini, kami Fakultas Ekonomi dan Manajamen Universitas Darussalam Gontor' , null, $indent2);
$section->addText("Kampus Putri memohon izin meminjam ". $data['nama_ruangan'] .' - '. $data['nama_gedung'] ." untuk ". $data['tujuan'] ." yang akan dilaksanakan pada:" , null, $indent);

$section->addText('Hari' . str_repeat(' ', 14) . ': ' . formatHari($data['tanggal_peminjaman']) , null, $indent2);
$section->addText('Tanggal' . str_repeat(' ', 8) . ': ' . formatTanggal($data['tanggal_peminjaman']), null, $indent2);
$section->addText('Keperluan' . str_repeat(' ', 5) . ': ' . $data['tujuan'], null, $indent2);

$section->addTextBreak();

$paragraph = $section->addTextRun();
$paragraph->addText('Menyetujui', array('italic' => true));
$paragraph->getParagraphStyle()->setAlignment('center');

$paragraph = $section->addTextRun();
$paragraph->addText('Kabag. Sarana dan Prasarana');
$paragraph->getParagraphStyle()->setAlignment('center');

$section->addTextBreak();
$section->addTextBreak();
$section->addTextBreak();

$paragraph = $section->addTextRun();
$paragraph->addText('Widya Kurniawan, S.Kom., M.Kom', ['bold' => true]);
$paragraph->getParagraphStyle()->setAlignment('center');

$objWriter = \PhpOffice\PhpWord\IOFactory::createWriter($phpWord, 'Word2007');
$objWriter->save('Data Peminjaman Ruangan.docx');

// download file
header("Content-Disposition: attachment; filename=Data Peminjaman Ruangan.docx");
readfile("Data Peminjaman Ruangan.docx");