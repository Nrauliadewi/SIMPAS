<nav class="navbar navbar-expand navbar-light topbar mb-4 static-top shadow">

<!-- Sidebar Toggle (Topbar) -->
<button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
    <i class="fa fa-bars"></i>
</button>

<!-- Topbar Search -->
<form
    class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 ">
    <div class="input-group">
        <h5><i>SIMPAS</i> (Sistem Informasi Sarana Prasarana)</h5>
    </div>
</form>

<!-- Topbar Navbar -->
<ul class="navbar-nav ml-auto" style="padding-left: 20px; width: 180px;">
<li class="dropdown">
    <a href="" id="drop" style="text-decoration: none;" data-toggle="dropdown">
                <div class="d-flex bd-highlight">
                    <div class="p-1 bd-highlight">
                        <span style="color: white;"><i class="fa fa-user" style="color: white;"> </i> <?= $_SESSION['nama'] ?></span>
                    </div>
                    <div class="ml-auto pl-4 bd-highlight" id="dropdownAH" style="visibility: visible;">
                        <i class="fa-solid fa-caret-down " style="color: #ffffff;"></i>
                    </div>
                </div>   
        
</a>
<!-- Tambahkan link stylesheet untuk FontAwesome -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
<ul class="dropdown-menu">
    <li class="dropdown" style="width: 90%; margin: 0 auto;">
        <a href="logout.php" data-method="POST" style="text-decoration: none;">
                <div class="d-flex bd-highlight mb-3">
                    <div class="p-1 bd-highlight">
                        Sign Out
                    </div>
                    <div class="ml-auto p-1 bd-highlight">
                        <i class="fa fa-sign-out-alt pull-right"></i>
                    </div>
                </div>   
        </a>
    </li>
</ul>
</li>
    <!-- Nav Item - Search Dropdown (Visible Only XS) -->
    <li class="nav-item dropdown no-arrow d-sm-none">
        <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button"
            data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="fas fa-search fa-fw"></i>
        </a>
        <!-- Dropdown - Messages -->
        <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in"
            aria-labelledby="searchDropdown">
            <form class="form-inline mr-auto w-100 navbar-search">
                <div class="input-group">
                    <input type="text" class="form-control bg-light border-0 small"
                        placeholder="Search for..." aria-label="Search"
                        aria-describedby="basic-addon2">
                    <div class="input-group-append">
                        <button class="btn btn-primary" type="button">
                            <i class="fas fa-search fa-sm"></i>
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </li>

</ul>

</nav>
<script>
    // $(document).ready(function() {
    //     $("#drop").hover(function() {
    //         $("#dropdownAH").css('visibility', 'visible');
    //     }, function() {
    //         $("#dropdownAH").css('visibility', 'hidden');
    //     }); 
    // });
</script>