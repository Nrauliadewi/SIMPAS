<!-- Page Heading -->
<?php require 'date_formatter.php'; ?>
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">Rekapitulasi Data Peminjaman Barang</h1>
    <?php if($_SESSION['level'] == 'user') : ?>
    <?php else: ?>
        <div>
            <a href="peminjaman_barang/print_index.php" target="_blank" class="d-none d-sm-inline-block btn btn-sm btn-outline-danger shadow-sm"> Export PDF</a>
            <a href="peminjaman_barang/excel_index.php" target="_blank" class="d-none d-sm-inline-block btn btn-sm btn-outline-success shadow-sm mx-2"> Export Excel</a>
            <a href="peminjaman_barang/word_index.php" target="_blank" class="d-none d-sm-inline-block btn btn-sm btn-outline-primary shadow-sm"> Export Word</a>
        </div>
    <?php endif ?>
</div>

<div class="card shadow mb-4">
    <div class="card-body">
        <div class="table-responsive">
            <?php if($_SESSION['level'] == 'user') { ?>
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Barang</th>
                        <th>Jumlah</th>
                        <th>Keperluan Acara</th>
                        <th>Tanggal Peminjaman</th>
                        <th>Tanggal Selesai</th>
                        <th>Penanggung Jawab</th>
                        <th>Satuan Kerja</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                <?php
                    $id_mahasiswa = $_SESSION['id'];
                    $no = 1;
                    $sql = mysqli_query($conn, "SELECT * FROM peminjaman_barang LEFT JOIN barang ON peminjaman_barang.barang_kd = barang.id LEFT JOIN biro ON peminjaman_barang.biro_id = biro.id_biro LEFT JOIN dosen ON dosen.id_dosen = peminjaman_barang.dosen_id LEFT JOIN satuan ON satuan.id_satuan = barang.satuan_id WHERE mahasiswa_id = '$id_mahasiswa' ORDER BY id_peminjaman_barang DESC");
                    while($row = mysqli_fetch_assoc($sql)){
                ?>
                <tr>
                    <td><?php echo $no++ ?></td>
                    <td><?php echo $row['nama_barang'] == '' ? '-' : $row['nama_barang']; ?></td>
                    <td><?php echo $row['jumlah_barang'] . ' ' . $row['nama_satuan'] ?></td>
                    <td><?php echo $row['tujuan'] ?></td>
                    <td><?php echo formatDateIndonesia2($row['tanggal_peminjaman']) ?></td>
                    <td><?php echo formatDateIndonesia2($row['tanggal_selesai']) ?></td>
                    <td><?php echo $row['nama_dosen'] == '' ? '-' : $row['nama_dosen']; ?></td>
                    <td><?php echo $row['nama_biro'] == '' ? '-' : $row['nama_biro']; ?></td>
                    <td>
                        <?php if($row['status'] == "Pending"){ ?>
                            <span class="badge badge-warning"><?php echo $row['status'] ?></span>
                        <?php } elseif($row['status'] == "Disapproved") { ?>
                            <span class="badge badge-danger"><?php echo $row['status'] ?></span>
                        <?php } elseif($row['status'] == "Approved") { ?>
                            <span class="badge badge-success"><?php echo $row['status'] ?></span>
                        <?php } else { ?>
                            <span class="badge badge-primary"><?php echo $row['status'] ?></span>
                        <?php } ?>
                    </td>
                    <td>
                        <a href="peminjaman_barang/cetak_word.php?id=<?php echo $row['id_peminjaman_barang'] ?>" target="_blank" class="d-none d-sm-inline-block btn btn-sm btn-outline-primary shadow-sm"> Cetak Surat</a>
                        <br>
                        
                        <a class="btn btn-sm btn-primary" href="admin.php?page=view-peminjaman-barang&id=<?php echo $row['id_peminjaman_barang'] ?>">View</a>
                        <!-- <a class="btn btn-sm btn-outline-success" target="_blank" href="peminjaman_barang/print_view.php?id=<?php echo $row['id_peminjaman_barang'] ?>">Print</a> -->
                    </td>
                </tr>
                <?php } ?>
                </tbody>
            </table>
            <?php }else{ ?>
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>NIM</th>
                        <th>Nama</th>
                        <th>Barang</th>
                        <th>Jumlah</th>
                        <th>Keperluan Acara</th>
                        <th>Tanggal Peminjaman</th>
                        <th>Tanggal Selesai</th>
                        <th>Penanggung Jawab</th>
                        <th>Satuan Kerja</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                <?php
                    $no = 1;
                    $sql = mysqli_query($conn, "SELECT * FROM peminjaman_barang LEFT JOIN barang ON peminjaman_barang.barang_kd = barang.id LEFT JOIN mahasiswa ON peminjaman_barang.mahasiswa_id = mahasiswa.id_mahasiswa LEFT JOIN biro ON peminjaman_barang.biro_id = biro.id_biro LEFT JOIN satuan ON satuan.id_satuan = barang.satuan_id LEFT JOIN dosen ON dosen.id_dosen = peminjaman_barang.dosen_id ORDER BY peminjaman_barang.id_peminjaman_barang DESC");
                    while($row = mysqli_fetch_assoc($sql)){
                ?>
                <tr>
                    <td><?php echo $no++ ?></td>
                    <td><?php echo $row['nim'] == '' ? '-' : $row['nim']; ?></td>
                    <td><?php echo $row['nama_mahasiswa'] == '' ? '-' : $row['nama_mahasiswa']; ?></td>
                    <td><?php echo $row['nama_barang'] == '' ? '-' : $row['nama_barang']; ?></td>
                    <td><?php echo $row['jumlah_barang'] . ' ' . $row['nama_satuan'] ?></td>
                    <td><?php echo $row['tujuan'] ?></td>
                    <td><?php echo formatDateIndonesia2($row['tanggal_peminjaman']) ?></td>
                    <td><?php echo formatDateIndonesia2($row['tanggal_selesai']) ?></td>
                    <td><?php echo $row['nama_dosen'] == '' ? '-' : $row['nama_dosen']; ?></td>
                    <td><?php echo $row['nama_biro'] == '' ? '-' : $row['nama_biro']; ?></td>
                    <td>
                        <?php if($row['status'] == "Pending"){ ?>
                            <span class="badge badge-warning"><?php echo $row['status'] ?></span>
                        <?php } elseif($row['status'] == "Disapproved") { ?>
                            <span class="badge badge-danger"><?php echo $row['status'] ?></span>
                        <?php } elseif($row['status'] == "Approved") { ?>
                            <span class="badge badge-success"><?php echo $row['status'] ?></span>
                        <?php } else { ?>
                            <span class="badge badge-primary"><?php echo $row['status'] ?></span>
                        <?php } ?>
                    </td>
                    <td>
                    <head>
                    <title>Icons</title>
                    <!-- Tambahkan link stylesheet untuk FontAwesome -->
                    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
                </head>
                <body>

                    <a class="btn btn-sm btn-primary" href="admin.php?page=view-peminjaman-barang&id=<?php echo $row['id_peminjaman_barang']?>">
                    <i class="fas fa-eye"></i> <!-- Menggunakan class "fas" untuk ikon solid -->
                </a>
                </body>

                <head>
                    <title>Icons</title>
                    <!-- Tambahkan link stylesheet untuk FontAwesome -->
                    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
                </head>
                <body>

                    <a class="btn btn-sm btn-danger" href="admin.php?page=hapus-peminjaman-barang&id=<?php echo $row['id_peminjaman_barang'] ?>">
                    <i class="fa-solid fa-trash"></i> <!-- Menggunakan class "fas" untuk ikon solid -->
                </a>
                </body>
                </td>
                </tr>
                <?php } ?>
                </tbody>
            </table>

            <?php } ?>
        </div>
    </div>
</div>