<?php
// Mendefinisikan parameter koneksi database
$servername = "localhost";
$username = "skewralv_simpas";
$password = "simpasunida";
$dbname = "skewralv_simpas";

// Membuat koneksi
$conn = new mysqli($servername, $username, $password, $dbname);

// Mengecek koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}
?>
<?php 
    if(isset($_GET['call'])) {
        $sql = mysqli_query($conn, "SELECT * FROM dosen WHERE id_biro='".$_GET['call']."'");
        $loop = [];
        while($row = mysqli_fetch_array($sql)) {
            $loop[] = [$row['id_dosen'], $row['nik'], $row['nama_dosen']];
        }
        echo json_encode($loop);
    }
?>