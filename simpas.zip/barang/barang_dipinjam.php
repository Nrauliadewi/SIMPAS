<!-- Page Heading -->
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">Data Barang Dipinjam</h1>
</div>

<div class="card shadow mb-4">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Kode Barang</th>
                        <th>Nama Barang</th>
                        <th>Tujuan</th>
                        <th>Tanggal Peminjaman</th>
                        <th>Tanggal Selesai</th>
                        <th>Penanggung Jawab</th>
                        <th>Satuan Kerja</th>
                        <th>Jumlah Barang Dipinjam</th>
                    </tr>
                </thead>
                <tbody>
                <?php
                    $no = 1;
                    $sql = mysqli_query($conn, "SELECT b.nama_barang, b.id, b.kd_barang, pb.jumlah_barang, pb.tanggal_peminjaman, pb.tanggal_selesai, pb.tujuan, pb.biro_id, biro.id_biro, dosen.id_dosen, biro.nama_biro, dosen.nama_dosen
                    FROM peminjaman_barang pb
                    INNER JOIN barang b ON pb.barang_kd = b.id LEFT JOIN biro ON pb.biro_id = biro.id_biro LEFT JOIN dosen ON dosen.id_dosen = pb.dosen_id
                    WHERE pb.status = 'Approved'");
                    while($row = mysqli_fetch_assoc($sql)){
                ?>
                <tr>
                    <td><?php echo $no++ ?></td>
                    <td><?php echo $row['kd_barang'] ?></td>
                    <td><?php echo $row['nama_barang'] ?></td>
                    <td><?php echo $row['tujuan'] ?></td>
                    <td><?php echo $row['tanggal_peminjaman'] ?></td>
                    <td><?php echo $row['tanggal_selesai'] ?></td>
                    <td><?php echo $row['nama_dosen'] == '' ? '-' : $row['nama_dosen']; ?></td>
                    <td><?php echo $row['nama_biro'] == '' ? '-' : $row['nama_biro']; ?></td>
                    <td><?php echo $row['jumlah_barang'] ?></td>
                </tr>
                <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
