<!-- Page Heading -->
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">Data Ruangan</h1>
    <?php if($_SESSION['level'] == 'admin'): ?>
    <a href="admin.php?page=tambah-ruangan" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"> Tambah Data</a>
    <?php endif; ?>
</div>

<div class="card shadow mb-4">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama Ruangan</th>
                        <th>Gedung</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                <?php
                    $no = 1;
                    $sql = mysqli_query($conn, "SELECT * FROM ruangan JOIN gedung ON ruangan.gedung_id=gedung.id_gedung");
                    while($row = mysqli_fetch_assoc($sql)){
                ?>
                <tr>
                    <td><?php echo $no++ ?></td>
                    <td><?php echo $row['nama_ruangan'] ?></td>
                    <td><?php echo $row['nama_gedung'] ?></td>
                    <?php if($_SESSION['level'] == 'admin'): ?>
                    <td>
                    <head>
                    <title>Icons</title>
                    <!-- Tambahkan link stylesheet untuk FontAwesome -->
                    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
                </head>
                <body>

                    <a class="btn btn-sm btn-primary" href="admin.php?page=edit-ruangan&id=<?php echo $row['id_ruangan']?>">
                    <i class="fa-regular fa-pen-to-square"></i> <!-- Menggunakan class "fas" untuk ikon solid -->
                </a>
                </body>

                <head>
                    <title>Icons</title>
                    <!-- Tambahkan link stylesheet untuk FontAwesome -->
                    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
                </head>
                <body>

                    <a class="btn btn-sm btn-danger" href="admin.php?page=hapus-ruangan&id=<?php echo $row['id_ruangan'] ?>">
                    <i class="fa-solid fa-trash"></i> <!-- Menggunakan class "fas" untuk ikon solid -->
                </a>
                </body>
                    <?php else: ?>
                        <td>
                        <a class="btn btn-sm btn-primary" href="admin.php?page=tambah-peminjaman-ruangan&id=<?= $row['id_ruangan'] ?>">Pinjam</a>
                        </td>
                    <?php endif ?>
                </tr>
                <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
